﻿using ABClassLibrary;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ABPatients.Models
{
    [ModelMetadataType(typeof(ABPatientMetadata))]
    public partial class Patient : IValidatableObject
    {
        ABPatientsContext _context = new ABPatientsContext();
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            //firstname is required
            FirstName = ABValidations.ABCapitalize(FirstName);
            if (FirstName == "")
            {
                yield return new ValidationResult("First Name cannot be null or just blanks", new[] { nameof(FirstName) }); 
            }

            //last name is required
            LastName = ABValidations.ABCapitalize(LastName);
            if (LastName == "")
            {
                yield return new ValidationResult("Last Name cannot be null or just blanks", new[] { nameof(LastName) });
            }

            //gender is required
            if (Gender == null)
            {
                yield return new ValidationResult("Gender cannot be null or just blanks", new[] { nameof(Gender) });
            }
            else
            {  
                //shift to upper case
                Gender = Gender.ToUpper();

                if(Gender != "M" && Gender != "F" && Gender != "X")
                {
                    yield return new ValidationResult("Gender must be either 'M', 'F' or 'X'", new[] { nameof(Gender) });
                }
            }

            //address optional, capitalize using class library method : ABCapitalize and address as a parameter
            if(Address != null)
            {
                Address = ABValidations.ABCapitalize(Address);
            }

            //city optional, capitalize using class library method : ABCapitalize and city as a parameter
            if (City != null)
            {
                City = ABValidations.ABCapitalize(City);
            }

            var province = _context.Province.Where(a => a.ProvinceCode == ProvinceCode).Any();

            if (ProvinceCode != null)
            {
                //error, if there is no province on record before 
                if (!province)
                {
                    yield return new ValidationResult("Province Code is not on file", new[] { nameof(ProvinceCode) });
                }
            }

            //if postal code provided, valid province code required
            if (PostalCode != null)
            {
                if (ProvinceCode == null)
                {
                    yield return new ValidationResult("Province code required to validate postal code", new[] { nameof(ProvinceCode) });
                }
                else
                {
                    var country = _context.Province.Where(a => a.ProvinceCode == ProvinceCode).FirstOrDefault();

                    if(country != null)
                    {
                        //If address is in canada
                        if (country.CountryCode == "CA")
                        {
                            //if postalcode is valid
                            if (ABValidations.ABPostalCodeValidation(PostalCode))
                            {
                                //reformat the postalcode
                                PostalCode = ABValidations.ABPostalCodeFormat(PostalCode);
                            }
                            else
                            {
                                // if postal code not valid 
                                yield return new ValidationResult("Canadian Postal Code not in correct format: A3A 3A3", new[] { nameof(PostalCode) });
                            }
                        }
                        //if address is in United States
                        else if (country.CountryCode == "US")
                        {
                            string postalCode = PostalCode;
                            //if zip code is valid
                            if (ABValidations.ABZipCodeValidation(ref postalCode))
                            {
                                PostalCode = postalCode;

                                //reformat 9 digit zip code to 55555-4444
                                if (PostalCode.Length == 9)
                                {
                                    PostalCode = String.Format("{0:#####-####}", PostalCode);
                                }
                            }
                            else
                            {
                                //if zip code not valid
                                yield return new ValidationResult("American Zip Code not in correct format: 55555 or 5555-4444", new[] { nameof(PostalCode) });
                            }
                        }
                        else
                        {
                            //if not,produce a pertinent error message for both fields
                            yield return new ValidationResult("First letter of postal code is not valid for given province", new[] { nameof(PostalCode) });
                        }
                    }
                   
                }
            }

            //ohip, if provided, shifted to upper case and validated to "1234-123-123-XX" pattern
            if(Ohip != null)
            {
                //error, if ohip not valid to 1234-123-123-XX pattern
                if (!ABValidations.ABOhipValidation(Ohip))
                {
                    yield return new ValidationResult("OHIP,if provided, must match pattern: 1234-123-123-XX", new[] { nameof(Ohip) });
                }
                else
                {
                    //shift it to upper case
                    Ohip = Ohip.Trim().ToUpper();
                }
            }

            //date of birth is optional, but if provided cannot be in future
            if (DateOfBirth > DateTime.Now)
            {
                yield return new ValidationResult("Date of birth cannot be in future", new[] { nameof(DateOfBirth) });
            }

            //home phone, if provided, must contain 10 digits and reformatted to "999-999-9999" pattern
            if(HomePhone != null)
            {
                //extract the digits and other text is discarded
                HomePhone = ABValidations.ABExtractDigits(HomePhone);
                if(HomePhone.Length < 10 && HomePhone.Length > 10)
                {
                    yield return new ValidationResult("Home phone, if provided, must be 10 digits: 123-123-1234", new[] { nameof(HomePhone) });
                }
                else
                {
                    //reformatted to "999-999-9999" pattern
                    HomePhone = String.Format("{0:###-###-####}", HomePhone);
                }
            }

            //date of death is optional, but if provided,cannot be in future
            if (DateOfDeath > DateTime.Now)
            {
                yield return new ValidationResult("Date of Death cannot be in the future",
                                    new[] { nameof(DateOfDeath) });
            }
            //nor before date of birth
            else if (DateOfDeath < DateOfBirth)
            {
                yield return new ValidationResult("Date of Death cannot be before Date of Birth",
                                    new[] { nameof(DateOfDeath) });
            }

            //if deceased is true, date of death is required
            if (Deceased)
            {
                if (DateOfDeath == null)
                {
                    yield return new ValidationResult("If deceased, date of Death is required",
                                        new[] { nameof(DateOfDeath) });
                }
            }
            //if not deceased, date of death should be null, error if not null
            else
            {
                //If dateOfDeath is not null, deceased must be true.
                if (DateOfDeath != null)
                {
                    yield return new ValidationResult("Deceased must be true if Date Of Death is provided",
                                        new[] { nameof(Deceased) });
                }
            }

            yield return ValidationResult.Success;
        }
    }
    public class ABPatientMetadata
    {
        public int PatientId { get; set; }
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        [Display(Name = "Last Name")]
        public string LastName { get; set; }
        [Display(Name="Street Address")]
        public string Address { get; set; }
        public string City { get; set; }
        [Display(Name = "Province Code")]
        public string ProvinceCode { get; set; }
        [Display(Name = "Postal Code")]
        public string PostalCode { get; set; }
        public string Ohip { get; set; }
        [Display(Name = "Date of Birth")]
        public DateTime? DateOfBirth { get; set; }
        public bool Deceased { get; set; }
        [Display(Name = "Date of Death")]
        public DateTime? DateOfDeath { get; set; }
        [Display(Name = "Home Phone")]
        public string HomePhone { get; set; }
        [StringLength(1)]
        public string Gender { get; set; }
    }
}
